# Predictor del Nivel del Mar

Proyecto de freeCodeCamp que analiza el aumento del nivel medio global del mar
desde 1880 y utiliza regresión lineal para proyectar el nivel hasta 2050.

## Archivos

- `sea_level_predictor.py`: carga los datos, calcula las regresiones y crea el gráfico.
- `main.py`: ejecuta el gráfico.
- `requirements.txt`: dependencias.
- `epa-sea-level.csv`: datos originales requeridos (del boilerplate oficial).
- `test_module.py`: pruebas oficiales (del boilerplate oficial).

## Instalar dependencias

```bash
python -m pip install -r requirements.txt
```

## Ejecutar

```bash
python main.py
```

Se genera `sea_level_plot.png`.

## Importante

Descarga `epa-sea-level.csv` y `test_module.py` desde el código inicial oficial
de freeCodeCamp y colócalos en esta misma carpeta.
