from sea_level_predictor import draw_plot
import matplotlib.pyplot as plt


if __name__ == "__main__":
    draw_plot()
    plt.show()
