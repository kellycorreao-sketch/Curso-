import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import linregress


def draw_plot():
    # Importar los datos
    df = pd.read_csv("epa-sea-level.csv")

    # Crear el gráfico de dispersión
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.scatter(
        df["Year"],
        df["CSIRO Adjusted Sea Level"],
        label="Datos observados",
    )

    # Regresión lineal con todos los datos
    all_years = df["Year"]
    all_sea_levels = df["CSIRO Adjusted Sea Level"]
    slope, intercept, r_value, p_value, std_err = linregress(
        all_years, all_sea_levels
    )

    years_extended = pd.Series(range(1880, 2051))
    ax.plot(
        years_extended,
        slope * years_extended + intercept,
        "r",
        label="Ajuste desde 1880",
    )

    # Regresión lineal desde el año 2000 hasta el más reciente
    recent_df = df[df["Year"] >= 2000]
    recent_slope, recent_intercept, _, _, _ = linregress(
        recent_df["Year"],
        recent_df["CSIRO Adjusted Sea Level"],
    )

    recent_years_extended = pd.Series(range(2000, 2051))
    ax.plot(
        recent_years_extended,
        recent_slope * recent_years_extended + recent_intercept,
        "green",
        label="Ajuste desde 2000",
    )

    # Etiquetas y título
    ax.set_xlabel("Year")
    ax.set_ylabel("Sea Level (inches)")
    ax.set_title("Rise in Sea Level")
    ax.legend()

    # Guardar y devolver la figura
    fig.savefig("sea_level_plot.png")
    return fig


if __name__ == "__main__":
    draw_plot()
