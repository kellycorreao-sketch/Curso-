import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np


def draw_cat_plot():
    # 1. Importar los datos
    df = pd.read_csv("medical_examination.csv")

    # 2. Agregar la columna overweight usando el IMC
    df["overweight"] = (
        df["weight"] / ((df["height"] / 100) ** 2) > 25
    ).astype(int)

    # 3. Normalizar colesterol y glucosa: 0 = bueno, 1 = malo
    df["cholesterol"] = (df["cholesterol"] > 1).astype(int)
    df["gluc"] = (df["gluc"] > 1).astype(int)

    # 4. Crear el DataFrame en formato largo
    df_cat = pd.melt(
        df,
        id_vars=["cardio"],
        value_vars=[
            "cholesterol",
            "gluc",
            "smoke",
            "alco",
            "active",
            "overweight",
        ],
    )

    # 5. Agrupar por enfermedad cardiovascular, variable y valor
    df_cat = (
        df_cat.groupby(["cardio", "variable", "value"])
        .size()
        .reset_index(name="total")
    )

    # 6. Crear el gráfico categórico
    fig = sns.catplot(
        data=df_cat,
        x="variable",
        y="total",
        hue="value",
        col="cardio",
        kind="bar",
    ).fig

    # 7. Guardar y devolver la figura
    fig.savefig("catplot.png")
    return fig


def draw_heat_map():
    # 8. Importar los datos
    df = pd.read_csv("medical_examination.csv")

    # 9. Limpiar los datos incorrectos
    df_heat = df[
        (df["ap_lo"] <= df["ap_hi"])
        & (df["height"] >= df["height"].quantile(0.025))
        & (df["height"] <= df["height"].quantile(0.975))
        & (df["weight"] >= df["weight"].quantile(0.025))
        & (df["weight"] <= df["weight"].quantile(0.975))
    ]

    # 10. Calcular la matriz de correlación
    corr = df_heat.corr()

    # 11. Crear la máscara para el triángulo superior
    mask = np.triu(np.ones_like(corr, dtype=bool))

    # 12. Configurar la figura
    fig, ax = plt.subplots(figsize=(12, 12))

    # 13. Dibujar el mapa de calor
    sns.heatmap(
        corr,
        mask=mask,
        annot=True,
        fmt=".1f",
        square=True,
        center=0,
        linewidths=0.5,
        cbar_kws={"shrink": 0.5},
        ax=ax,
    )

    # 14. Guardar y devolver la figura
    fig.savefig("heatmap.png")
    return fig


if __name__ == "__main__":
    draw_cat_plot()
    draw_heat_map()
