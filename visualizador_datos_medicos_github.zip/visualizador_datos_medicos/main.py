from medical_data_visualizer import draw_cat_plot, draw_heat_map
import matplotlib.pyplot as plt


if __name__ == "__main__":
    draw_cat_plot()
    draw_heat_map()
    plt.show()
