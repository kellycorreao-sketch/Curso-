# Visualizador de Datos Médicos

Proyecto de freeCodeCamp para analizar y visualizar datos de exámenes médicos
utilizando Python, Pandas, Matplotlib, NumPy y Seaborn.

## Archivos

- `medical_data_visualizer.py`: funciones `draw_cat_plot()` y `draw_heat_map()`.
- `main.py`: ejecuta ambas visualizaciones.
- `medical_examination.csv`: conjunto de datos requerido (se obtiene del boilerplate oficial).
- `test_module.py`: pruebas oficiales del proyecto (se obtienen del boilerplate oficial).

## Instalar dependencias

```bash
python -m pip install pandas matplotlib seaborn numpy
```

## Ejecutar

```bash
python main.py
```

Se generan dos imágenes:
- `catplot.png`: gráfico categórico separado por pacientes con y sin enfermedad cardiovascular.
- `heatmap.png`: mapa de calor de correlaciones tras limpiar los datos.

## Importante

Descarga `medical_examination.csv` y `test_module.py` desde el código inicial oficial
de freeCodeCamp y colócalos en esta misma carpeta. No subas un archivo CSV distinto:
las pruebas esperan el conjunto de datos original.
