# Analizador de Datos Demográficos

Proyecto de freeCodeCamp que analiza datos del censo de 1994 usando Python y Pandas.

## Archivos

- `demographic_data_analyzer.py`: contiene la función `calculate_demographic_data()`.
- `main.py`: ejecuta el análisis.
- `adult.data.csv`: archivo de datos requerido (debe estar en la misma carpeta).

## Instalación

```bash
python -m pip install pandas
```

## Ejecución

```bash
python main.py
```

## Importante: archivo de datos

Descarga el archivo `adult.data.csv` desde el código inicial oficial de freeCodeCamp
(boilerplate-demographic-data-analyzer) y colócalo en la misma carpeta que
`demographic_data_analyzer.py`.

El proyecto también debe conservar `test_module.py` del boilerplate oficial para
ejecutar las pruebas unitarias.
