import pandas as pd


def calculate_demographic_data(print_data=True):
    # Leer los datos del censo
    df = pd.read_csv("adult.data.csv")

    # 1. Cantidad de personas de cada raza
    race_count = df["race"].value_counts()

    # 2. Edad promedio de los hombres
    average_age_men = round(df.loc[df["sex"] == "Male", "age"].mean(), 1)

    # 3. Porcentaje de personas con título de licenciatura (Bachelors)
    percentage_bachelors = round(
        (df["education"] == "Bachelors").mean() * 100, 1
    )

    # 4. Porcentajes de personas con y sin educación avanzada que ganan >50K
    higher_education = df["education"].isin(
        ["Bachelors", "Masters", "Doctorate"]
    )
    lower_education = ~higher_education

    higher_education_rich = round(
        (df.loc[higher_education, "salary"] == ">50K").mean() * 100, 1
    )
    lower_education_rich = round(
        (df.loc[lower_education, "salary"] == ">50K").mean() * 100, 1
    )

    # 5. Mínimo de horas trabajadas por semana
    min_work_hours = df["hours-per-week"].min()

    # 6. Porcentaje de quienes trabajan el mínimo de horas y ganan >50K
    num_min_workers = df[df["hours-per-week"] == min_work_hours]
    rich_percentage = round(
        (num_min_workers["salary"] == ">50K").mean() * 100, 1
    )

    # 7. País con el mayor porcentaje de personas que ganan >50K
    people_by_country = df["native-country"].value_counts()
    rich_by_country = df.loc[
        df["salary"] == ">50K", "native-country"
    ].value_counts()

    country_percentage = (rich_by_country / people_by_country) * 100
    higher_earning_country = country_percentage.idxmax()
    higher_earning_country_percentage = round(country_percentage.max(), 1)

    # 8. Ocupación más popular en India entre quienes ganan >50K
    top_IN_occupation = (
        df.loc[
            (df["native-country"] == "India") & (df["salary"] == ">50K"),
            "occupation",
        ]
        .value_counts()
        .idxmax()
    )

    if print_data:
        print("Cantidad de personas por raza:\n", race_count)
        print("Edad promedio de los hombres:", average_age_men)
        print("Porcentaje con licenciatura:", percentage_bachelors)
        print("Porcentaje con educación avanzada que gana >50K:",
              higher_education_rich)
        print("Porcentaje sin educación avanzada que gana >50K:",
              lower_education_rich)
        print("Mínimo de horas trabajadas por semana:", min_work_hours)
        print("Porcentaje de quienes trabajan el mínimo y ganan >50K:",
              rich_percentage)
        print("País con mayor porcentaje de ingresos >50K:",
              higher_earning_country)
        print("Porcentaje de ese país:", higher_earning_country_percentage)
        print("Ocupación más popular en India para ingresos >50K:",
              top_IN_occupation)

    return {
        "race_count": race_count,
        "average_age_men": average_age_men,
        "percentage_bachelors": percentage_bachelors,
        "higher_education_rich": higher_education_rich,
        "lower_education_rich": lower_education_rich,
        "min_work_hours": min_work_hours,
        "rich_percentage": rich_percentage,
        "higher_earning_country": higher_earning_country,
        "higher_earning_country_percentage": higher_earning_country_percentage,
        "top_IN_occupation": top_IN_occupation,
    }


if __name__ == "__main__":
    calculate_demographic_data()
