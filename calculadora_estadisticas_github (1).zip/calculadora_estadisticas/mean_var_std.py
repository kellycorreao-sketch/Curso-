import numpy as np


def calculate(numbers):
    """
    Calcula media, varianza, desviación estándar, máximo, mínimo y suma
    para las filas, columnas y todos los elementos de una matriz 3 x 3.

    Args:
        numbers: Lista de exactamente 9 números.

    Returns:
        Diccionario con los resultados como listas y valores escalares.

    Raises:
        ValueError: Si la lista no contiene exactamente 9 números.
    """
    if len(numbers) != 9:
        raise ValueError("List must contain nine numbers.")

    matrix = np.array(numbers).reshape(3, 3)

    calculations = {
        "mean": [
            np.mean(matrix, axis=0).tolist(),
            np.mean(matrix, axis=1).tolist(),
            np.mean(matrix).item(),
        ],
        "variance": [
            np.var(matrix, axis=0).tolist(),
            np.var(matrix, axis=1).tolist(),
            np.var(matrix).item(),
        ],
        "standard deviation": [
            np.std(matrix, axis=0).tolist(),
            np.std(matrix, axis=1).tolist(),
            np.std(matrix).item(),
        ],
        "max": [
            np.max(matrix, axis=0).tolist(),
            np.max(matrix, axis=1).tolist(),
            np.max(matrix).item(),
        ],
        "min": [
            np.min(matrix, axis=0).tolist(),
            np.min(matrix, axis=1).tolist(),
            np.min(matrix).item(),
        ],
        "sum": [
            np.sum(matrix, axis=0).tolist(),
            np.sum(matrix, axis=1).tolist(),
            np.sum(matrix).item(),
        ],
    }

    return calculations
