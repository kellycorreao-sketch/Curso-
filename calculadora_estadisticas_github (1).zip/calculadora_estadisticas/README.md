# Calculadora de estadísticas (freeCodeCamp)

Proyecto en Python que utiliza NumPy para calcular media, varianza,
desviación estándar, máximo, mínimo y suma de una matriz de 3 x 3.

## Archivos
- `mean_var_std.py`: contiene la función `calculate(numbers)`.
- `main.py`: permite ejecutar una prueba rápida.

## Requisito
Instalar NumPy:

```bash
python -m pip install numpy
```

## Ejecutar

```bash
python main.py
```

La función recibe una lista de exactamente 9 números. Si recibe una cantidad
diferente, genera `ValueError` con el mensaje:
`List must contain nine numbers.`

Los resultados se devuelven en un diccionario y los arreglos NumPy se
convierten a listas de Python.
