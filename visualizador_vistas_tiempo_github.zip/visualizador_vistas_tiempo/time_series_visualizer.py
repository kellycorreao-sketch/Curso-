import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# Importar los datos y establecer date como índice
df = pd.read_csv("fcc-forum-pageviews.csv", parse_dates=["date"], index_col="date")

# Eliminar el 2.5% inferior y superior de las vistas
df = df[
    (df["value"] >= df["value"].quantile(0.025))
    & (df["value"] <= df["value"].quantile(0.975))
]


def draw_line_plot():
    # Copia de los datos para el gráfico
    df_line = df.copy()

    fig, ax = plt.subplots(figsize=(15, 5))
    ax.plot(df_line.index, df_line["value"], color="red", linewidth=1)

    ax.set_title("Daily freeCodeCamp Forum Page Views 5/2016-12/2019")
    ax.set_xlabel("Date")
    ax.set_ylabel("Page Views")

    fig.savefig("line_plot.png")
    return fig


def draw_bar_plot():
    # Copia de los datos y creación de columnas de año y mes
    df_bar = df.copy()
    df_bar["year"] = df_bar.index.year
    df_bar["month"] = df_bar.index.month

    # Promedio de vistas por mes, agrupado por año
    df_bar = (
        df_bar.groupby(["year", "month"])["value"]
        .mean()
        .unstack()
    )

    fig = df_bar.plot(
        kind="bar",
        figsize=(10, 6),
        legend=True,
    ).get_figure()

    plt.xlabel("Years")
    plt.ylabel("Average Page Views")
    plt.legend(
        title="Months",
        labels=[
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December",
        ],
    )
    plt.tight_layout()

    fig.savefig("bar_plot.png")
    return fig


def draw_box_plot():
    # Copia de los datos y preparación de columnas para los gráficos
    df_box = df.copy()
    df_box.reset_index(inplace=True)
    df_box["year"] = df_box["date"].dt.year
    df_box["month"] = df_box["date"].dt.strftime("%b")

    # Orden cronológico de los meses
    month_order = [
        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
    ]
    df_box["month"] = pd.Categorical(
        df_box["month"], categories=month_order, ordered=True
    )

    fig, axes = plt.subplots(1, 2, figsize=(20, 6))

    # Diagrama por año: tendencia
    sns.boxplot(
        data=df_box,
        x="year",
        y="value",
        ax=axes[0],
    )
    axes[0].set_title("Year-wise Box Plot (Trend)")
    axes[0].set_xlabel("Year")
    axes[0].set_ylabel("Page Views")
    axes[0].tick_params(axis="x", rotation=45)

    # Diagrama por mes: estacionalidad
    sns.boxplot(
        data=df_box,
        x="month",
        y="value",
        ax=axes[1],
        order=month_order,
    )
    axes[1].set_title("Month-wise Box Plot (Seasonality)")
    axes[1].set_xlabel("Month")
    axes[1].set_ylabel("Page Views")

    fig.tight_layout()
    fig.savefig("box_plot.png")
    return fig


if __name__ == "__main__":
    draw_line_plot()
    draw_bar_plot()
    draw_box_plot()
