from time_series_visualizer import (
    draw_line_plot,
    draw_bar_plot,
    draw_box_plot,
)
import matplotlib.pyplot as plt


if __name__ == "__main__":
    draw_line_plot()
    draw_bar_plot()
    draw_box_plot()
    plt.show()
