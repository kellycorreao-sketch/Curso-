# Visualizador de Vistas de Página en el Tiempo

Proyecto de freeCodeCamp para analizar las vistas diarias del foro de freeCodeCamp
entre mayo de 2016 y diciembre de 2019 usando Pandas, Matplotlib y Seaborn.

## Archivos

- `time_series_visualizer.py`: carga, limpieza y funciones de visualización.
- `main.py`: ejecuta los tres gráficos.
- `requirements.txt`: dependencias del proyecto.
- `fcc-forum-pageviews.csv`: archivo de datos requerido, del boilerplate oficial.
- `test_module.py`: pruebas oficiales, del boilerplate oficial.

## Instalar dependencias

```bash
python -m pip install -r requirements.txt
```

## Ejecutar

```bash
python main.py
```

Se generan:
- `line_plot.png`
- `bar_plot.png`
- `box_plot.png`

## Importante

Descarga `fcc-forum-pageviews.csv` y `test_module.py` desde el código inicial oficial
de freeCodeCamp y colócalos en la misma carpeta que `time_series_visualizer.py`.
